/**
 * 藏经阁 · 设计台
 * 白名单积木拼装 content 卷 → 导出 pack.json + content.json
 * 无任意可执行脚本注入游戏；未知 kind 不出现。
 */
(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

  const TOKEN_KEY = 'dlc_designer_upload_token';
  const ID_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/;

  /** @type {any} */
  let SCHEMA = null;

  const state = {
    pack: {
      id: 'my-pack',
      kind: 'pack',
      name: '未名卷',
      version: '0.1.0',
      description: '设计台试笔。',
      tags: [],
      builtin: false,
    },
    content: {
      weaponLooks: [],
      animRecipes: [],
      silhouettes: [],
      behaviors: [],
      weapons: [],
      skills: [],
      talismans: [],
      enemies: [],
      stages: [],
    },
    sel: {
      weaponLooks: 0,
      animRecipes: 0,
      silhouettes: 0,
      behaviors: 0,
    },
    gpKind: 'weapons',
    gpSel: 0,
    stageSel: 0,
  };

  /** @type {Record<string, any>|null} */
  let STAGE_SKELS = null;

  const LIST_KEYS = {
    weaponLooks: { listKey: 'parts', schemaKey: 'parts', itemLabel: '部件' },
    animRecipes: { listKey: 'steps', schemaKey: 'steps', itemLabel: '步骤' },
    silhouettes: { listKey: 'parts', schemaKey: 'parts', itemLabel: '部件' },
    behaviors: { listKey: 'steps', schemaKey: 'steps', itemLabel: '步骤' },
  };

  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { el.hidden = true; }, 2200);
  }

  function deepClone(o) {
    return JSON.parse(JSON.stringify(o));
  }

  function getAt(obj, path) {
    if (!path.includes('.')) return obj[path];
    const parts = path.split('.');
    let cur = obj;
    for (const p of parts) {
      if (cur == null || typeof cur !== 'object') return undefined;
      cur = cur[p];
    }
    return cur;
  }

  function setAt(obj, path, value) {
    if (!path.includes('.')) {
      if (value === undefined) delete obj[path];
      else obj[path] = value;
      return;
    }
    const parts = path.split('.');
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      const p = parts[i];
      if (cur[p] == null || typeof cur[p] !== 'object' || Array.isArray(cur[p])) cur[p] = {};
      cur = cur[p];
    }
    const last = parts[parts.length - 1];
    if (value === undefined) delete cur[last];
    else cur[last] = value;
  }

  function parseMaterialMap(raw) {
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) return raw;
    const out = {};
    String(raw || '')
      .split(/[,，]+/)
      .map((s) => s.trim())
      .filter(Boolean)
      .forEach((pair) => {
        const m = pair.match(/^([a-zA-Z_][\w]*)\s*[:=]\s*(\d+)$/);
        if (m) out[m[1]] = Number(m[2]);
      });
    return Object.keys(out).length ? out : undefined;
  }

  function formatMaterialMap(obj) {
    if (!obj || typeof obj !== 'object') return '';
    return Object.entries(obj).map(([k, v]) => k + ':' + v).join(', ');
  }

  function emptyDef(section) {
    if (section === 'weaponLooks') {
      return { id: `look_${Date.now().toString(36).slice(-5)}`, label: '', baseShape: 'sword', parts: [] };
    }
    if (section === 'animRecipes') {
      return { id: `anim_${Date.now().toString(36).slice(-5)}`, label: '', steps: [] };
    }
    if (section === 'silhouettes') {
      return { id: `sil_${Date.now().toString(36).slice(-5)}`, label: '', body: 'spear', baseRig: 'spear', parts: [] };
    }
    if (section === 'behaviors') {
      return { id: `beh_${Date.now().toString(36).slice(-5)}`, label: '', body: 'spear', steps: [] };
    }
    return { id: `item_${Date.now().toString(36).slice(-5)}` };
  }

  function emptyGameplay(kind) {
    const id = `${kind.slice(0, 3)}_${Date.now().toString(36).slice(-5)}`;
    if (kind === 'weapons') {
      const lookFallback = (state.content.weaponLooks[0] && state.content.weaponLooks[0].id) || '';
      return {
        id,
        name: '无名兵刃',
        lore: '设计台试笔之刃。',
        tip: '试笔兵刃',
        unlock: { type: 'blueprint', hint: '设计台试笔' },
        damage: 1, speed: 1, reach: 1, poise: 1, rage: 1, airHover: 1,
        weight: 'medium',
        category: 'blade',
        affinities: ['juggle'],
        affinityBonus: 0.1,
        blade: '#e9eef7', trail: '#ff2040', edge: '#ff4a66',
        length: 56,
        shape: 'sword',
        quality: 'fan',
        tier: 1,
        lookId: lookFallback,
        feel: { boxTune: {} },
        craft: { materials: { iron: 1 }, fee: 10 },
      };
    }
    if (kind === 'skills') {
      return {
        id,
        name: '无名外功',
        fogName: '武学·??',
        kind: 'active',
        track: 'combat',
        lore: '设计台试笔外功。',
        tip: '挂既有攻击盒试斩',
        profHint: '施放本招',
        meditateCost: {},
        fee: 0,
        quality: 'fan',
        weaponGate: 'any',
        neiliCost: 20,
        castKind: 'attack',
        attackKey: 'slash1',
        commandSeq: ['D', 'F'],
        commandLabel: '↓→攻',
        hudHint: '试笔↓→J',
        touchPriority: 40,
      };
    }
    if (kind === 'talismans') {
      return {
        id, name: '无名符', tip: '', color: '#c8a060', quality: 'fan', grade: 'xia',
        anim: '', scriptId: '', fee: 8, stockCap: 2, runCharges: 1,
      };
    }
    if (kind === 'enemies') {
      return {
        id, name: '无名敌', hp: 55,
        silhouetteId: 'spear', behaviorId: 'spear', colliderId: 'spear',
        dropChance: 0.2, eliteEligible: true,
      };
    }
    return { id };
  }

  function kindMeta(section, kind) {
    const bag = SCHEMA[section];
    if (!bag) return null;
    const list = bag.parts || bag.steps || [];
    return list.find((x) => x.kind === kind) || null;
  }

  function coerceValue(type, raw, field) {
    if (type === 'number') {
      if (raw === '' || raw == null) return undefined;
      let n = Number(raw);
      if (Number.isNaN(n)) return undefined;
      if (field && field.min != null) n = Math.max(field.min, n);
      if (field && field.max != null) n = Math.min(field.max, n);
      return n;
    }
    if (type === 'boolean') return Boolean(raw);
    if (type === 'stringList') {
      if (Array.isArray(raw)) return raw;
      return String(raw || '')
        .split(/[,，\s]+/)
        .map((s) => s.trim())
        .filter(Boolean);
    }
    if (type === 'materialMap') {
      return parseMaterialMap(raw);
    }
    if (type === 'enum' && (raw === '1' || raw === '-1')) {
      return Number(raw);
    }
    if (raw === '' || raw == null) return undefined;
    return raw;
  }

  function buildContentExport() {
    const c = {};
    const keys = [
      'weaponLooks', 'animRecipes', 'silhouettes', 'behaviors',
      'weapons', 'skills', 'talismans', 'enemies', 'stages',
    ];
    for (const k of keys) {
      const arr = state.content[k];
      if (Array.isArray(arr) && arr.length) c[k] = deepClone(arr);
    }
    return c;
  }

  function buildPackExport() {
    const p = {
      id: state.pack.id,
      kind: state.pack.kind,
      name: state.pack.name,
      version: state.pack.version,
      description: state.pack.description || '',
      builtin: Boolean(state.pack.builtin),
    };
    if (state.pack.tags && state.pack.tags.length) p.tags = [...state.pack.tags];
    return p;
  }

  function buildUploadPayload() {
    return { pack: buildPackExport(), content: buildContentExport() };
  }

  function downloadJson(filename, obj) {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  }

  /* ── Meta form ─────────────────────────────────────────── */

  function renderMeta() {
    const root = $('#meta-form');
    root.innerHTML = '';

    const fields = [
      { key: 'id', label: '卷号 id', type: 'string' },
      { key: 'name', label: '卷名', type: 'string' },
      { key: 'kind', label: '类型', type: 'enum', enum: ['pack', 'menpai'] },
      { key: 'version', label: '版本', type: 'string' },
      { key: 'description', label: '跋语', type: 'string', span: 2 },
    ];

    for (const f of fields) {
      const lab = document.createElement('label');
      lab.className = `field${f.span === 2 ? ' span-2' : ''}`;
      const span = document.createElement('span');
      span.textContent = f.label;
      lab.append(span);
      let input;
      if (f.type === 'enum') {
        input = document.createElement('select');
        for (const opt of f.enum) {
          const o = document.createElement('option');
          o.value = opt;
          o.textContent = opt === 'menpai' ? '门派 menpai' : '内容卷 pack';
          if (state.pack[f.key] === opt) o.selected = true;
          input.append(o);
        }
      } else {
        input = document.createElement(f.key === 'description' ? 'textarea' : 'input');
        if (f.key === 'description') input.rows = 3;
        else input.type = 'text';
        input.value = state.pack[f.key] ?? '';
      }
      input.addEventListener('change', () => {
        state.pack[f.key] = input.value;
        if (f.key === 'id') refreshExportPreview();
      });
      input.addEventListener('input', () => {
        state.pack[f.key] = input.value;
      });
      lab.append(input);
      root.append(lab);
    }

    const tagLab = document.createElement('div');
    tagLab.className = 'field span-2';
    tagLab.innerHTML = '<span>标签 tags</span>';
    const row = document.createElement('div');
    row.className = 'tag-check-row';
    for (const t of SCHEMA.tags) {
      const lab = document.createElement('label');
      lab.className = 'tag-check';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = t.id;
      cb.checked = state.pack.tags.includes(t.id);
      cb.addEventListener('change', () => {
        if (cb.checked) {
          if (!state.pack.tags.includes(t.id)) state.pack.tags.push(t.id);
        } else {
          state.pack.tags = state.pack.tags.filter((x) => x !== t.id);
        }
      });
      lab.append(cb, document.createTextNode(t.label));
      lab.title = t.id;
      row.append(lab);
    }
    tagLab.append(row);
    root.append(tagLab);
  }

  /* ── Block tray ────────────────────────────────────────── */

  function renderTray(section) {
    const tray = $(`#tray-${section}`);
    if (!tray) return;
    const bag = SCHEMA[section];
    const items = bag.parts || bag.steps || [];
    tray.innerHTML = '';
    const h = document.createElement('h3');
    h.textContent = `积木 · ${bag.label}`;
    tray.append(h);

    const groups = new Map();
    for (const it of items) {
      const g = it.group || '白名单';
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(it);
    }
    for (const [g, list] of groups) {
      const wrap = document.createElement('div');
      wrap.className = 'tray-group';
      const title = document.createElement('div');
      title.className = 'tray-group-title';
      title.textContent = g;
      wrap.append(title);
      for (const it of list) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'block-btn';
        const icon = it.icon || (it.label || it.kind).slice(0, 1);
        const hint = it.hint || '';
        btn.innerHTML = `<span class="block-icon">${icon}</span><span class="block-text"><strong>${it.label || it.kind}</strong><em>${hint}</em></span>`;
        btn.title = hint || it.kind;
        btn.addEventListener('click', () => addBlock(section, it.kind));
        wrap.append(btn);
      }
      tray.append(wrap);
    }
  }

  function addBlock(section, kind) {
    const meta = kindMeta(section, kind);
    if (!meta) return;
    const cfg = LIST_KEYS[section];
    const list = state.content[section];
    if (!list.length) {
      list.push(emptyDef(section));
      state.sel[section] = 0;
    }
    const idx = Math.min(state.sel[section], list.length - 1);
    const def = list[idx];
    if (!Array.isArray(def[cfg.listKey])) def[cfg.listKey] = [];
    const step = { kind };
    // sensible defaults for required-ish fields
    if (kind === 'wait') step.frames = 8;
    if (kind === 'sfx') step.id = 'slash';
    if (kind === 'flash') { step.color = '#ffe0a0'; step.a = 0.12; }
    if (kind === 'hitstop') step.frames = 4;
    if (kind === 'shake') { step.amp = 3; step.frames = 6; }
    if (kind === 'tintCaster') { step.color = '#e8c070'; step.frames = 12; }
    if (kind === 'playPose' || kind === 'holdPose' || kind === 'loopPose') {
      step.poseId = 'slash1';
      if (kind !== 'playPose') step.frames = 8;
    }
    if (kind === 'bounce') step.hops = 2;
    if (kind === 'hover') step.frames = 12;
    if (kind === 'chainPose') step.poseIds = ['slash1', 'slash2'];
    if (kind === 'face') step.dir = 'player';
    if (kind === 'scale') step.value = 1;
    if (kind === 'keepDistance') {
      step.idealMin = 90; step.idealMax = 165; step.chase = 240;
    }
    if (kind === 'meleeAttack') { step.rangeMax = 160; step.attackKey = 'thrust'; }
    if (kind === 'rangedAttack') { step.rangeMin = 120; step.rangeMax = 320; }
    if (kind === 'spriteOverlay') step.sheetId = '';
    if (kind === 'dodge') { step.direction = 'away'; step.range = 100; step.weight = 1; }
    if (kind === 'circleStrafe') { step.radius = 130; step.speed = 1.3; step.weight = 0.7; }
    if (kind === 'flank') { step.preferBehind = true; step.weight = 0.6; }
    if (kind === 'callAlly') { step.enemyId = 'axe'; step.max = 1; step.cooldown = 180; step.weight = 0.8; }
    if (kind === 'phaseAtHp') { step.below = 0.4; step.setPhase = '残局'; }
    if (kind === 'phaseGate') { step.phase = '残局'; }
    if (kind === 'comboChain') { step.attackKeys = ['thrust', 'lunge']; step.gapFrames = 10; step.rangeMax = 180; step.weight = 1; }
    if (kind === 'retreatBurst') { step.dist = 90; step.frames = 12; step.weight = 0.6; }
    if (kind === 'taunt') { step.text = '来啊！'; step.weight = 0.4; }
    if (kind === 'idleEmote') { step.text = '……'; step.weight = 0.2; }
    if (kind === 'cloak') { step.style = 'long'; step.sway = 1; }
    if (kind === 'armorLayer') { step.slot = 'chest'; step.style = 'light'; }
    if (kind === 'ornament') { step.slot = 'waist'; step.style = 'bell'; }
    if (kind === 'faceMark') { step.style = 'scar'; }
    if (kind === 'stanceBias') { step.lean = 0.1; step.crouch = 0; }
    if (kind === 'damageBox') { step.w = 80; step.h = 50; step.damage = 12; step.ox = 50; }
    if (kind === 'damageDonut') { step.rInner = 40; step.rOuter = 120; step.damage = 10; }
    if (kind === 'zone') { step.shape = 'circle'; step.duration = 120; step.radius = 70; step.tickDamage = 2; }
    if (kind === 'pull') { step.radius = 140; step.strength = 2.5; step.frames = 20; }
    if (kind === 'root') { step.duration = 60; step.radius = 120; }
    if (kind === 'multihit') { step.times = 3; step.gapFrames = 6; step.step = { kind: 'damageRadius', rx: 60, damage: 6 }; }
    def[cfg.listKey].push(step);
    renderRecipeEditor(section);
    toast(`已加入「${meta.label || kind}」`);
  }

  /* ── Recipe editor ─────────────────────────────────────── */

  function renderSelect(section) {
    const sel = $(`#sel-${section}`);
    if (!sel) return;
    const list = state.content[section];
    sel.innerHTML = '';
    if (!list.length) {
      const o = document.createElement('option');
      o.value = '-1';
      o.textContent = '（尚无配方）';
      sel.append(o);
      return;
    }
    list.forEach((d, i) => {
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = `${d.id || '未编号'}${d.label ? ' · ' + d.label : ''}`;
      if (i === state.sel[section]) o.selected = true;
      sel.append(o);
    });
  }

  function renderDefFields(section, def, container) {
    const bag = SCHEMA[section];
    const grid = document.createElement('div');
    grid.className = 'form-grid';
    for (const f of bag.defFields) {
      const lab = document.createElement('label');
      lab.className = 'field';
      const span = document.createElement('span');
      span.textContent = f.label || f.key;
      lab.append(span);
      let input;
      if (f.type === 'enum') {
        input = document.createElement('select');
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = '—';
        input.append(empty);
        for (const opt of f.enum) {
          const o = document.createElement('option');
          o.value = opt;
          o.textContent = opt;
          if (String(def[f.key] ?? '') === String(opt)) o.selected = true;
          input.append(o);
        }
      } else {
        input = document.createElement('input');
        input.type = 'text';
        input.value = def[f.key] ?? '';
      }
      input.addEventListener('change', () => {
        const v = coerceValue(f.type === 'enum' ? 'string' : f.type, input.value, f);
        if (v === undefined || v === '') delete def[f.key];
        else def[f.key] = v;
        renderSelect(section);
        updatePreview(section);
        refreshExportPreview();
      });
      lab.append(input);
      grid.append(lab);
    }
    container.append(grid);
  }

  function renderFieldInput(field, obj, onChange) {
    const lab = document.createElement('label');
    lab.className = 'field';
    const span = document.createElement('span');
    span.textContent = (field.label || field.key) + (field.required ? ' *' : '');
    if (field.key && field.label && field.label !== field.key) {
      span.title = field.key;
    }
    if (field.hint) span.title = (span.title ? span.title + ' · ' : '') + field.hint;
    lab.append(span);

    let input;
    const path = field.key;
    const cur = getAt(obj, path);

    const commit = (v) => {
      if (v === undefined || v === '' || (Array.isArray(v) && !v.length)) setAt(obj, path, undefined);
      else setAt(obj, path, v);
      // prune empty feel/unlock/craft shells
      if (obj.feel && obj.feel.boxTune && !Object.keys(obj.feel.boxTune).length) {
        delete obj.feel.boxTune;
      }
      if (obj.feel && !Object.keys(obj.feel).length) delete obj.feel;
      onChange();
    };

    if (field.type === 'boolean') {
      input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = Boolean(cur);
      input.addEventListener('change', () => {
        setAt(obj, path, input.checked);
        onChange();
      });
    } else if (field.type === 'enum') {
      input = document.createElement('select');
      const empty = document.createElement('option');
      empty.value = '';
      empty.textContent = '—';
      input.append(empty);
      // dynamic lookId options
      let opts = field.enum || [];
      if (path === 'lookId') {
        const fromPack = (state.content.weaponLooks || []).map((x) => x.id).filter(Boolean);
        opts = [...new Set([...(opts || []), ...fromPack])];
      }
      for (const opt of opts) {
        const o = document.createElement('option');
        o.value = String(opt);
        o.textContent = String(opt);
        if (String(cur ?? '') === String(opt)) o.selected = true;
        input.append(o);
      }
      input.addEventListener('change', () => {
        const v = coerceValue('enum', input.value, field);
        if (v === undefined || input.value === '') commit(undefined);
        else commit(v);
      });
    } else if (field.type === 'color') {
      const wrap = document.createElement('div');
      wrap.style.display = 'flex';
      wrap.style.gap = '0.35rem';
      const color = document.createElement('input');
      color.type = 'color';
      const text = document.createElement('input');
      text.type = 'text';
      text.placeholder = '#rrggbb';
      const hex = typeof cur === 'string' && /^#[0-9a-fA-F]{6}$/.test(cur) ? cur : '#c8b090';
      color.value = hex;
      text.value = cur ?? '';
      const sync = () => {
        const v = text.value.trim();
        if (!v) commit(undefined);
        else {
          setAt(obj, path, v);
          if (/^#[0-9a-fA-F]{6}$/.test(v)) color.value = v;
          onChange();
        }
      };
      color.addEventListener('input', () => { text.value = color.value; sync(); });
      text.addEventListener('change', sync);
      wrap.append(color, text);
      lab.append(wrap);
      return lab;
    } else if (field.type === 'number') {
      input = document.createElement('input');
      input.type = 'number';
      if (field.min != null) input.min = field.min;
      if (field.max != null) input.max = field.max;
      input.step = 'any';
      input.value = cur != null ? cur : '';
      input.addEventListener('change', () => {
        commit(coerceValue('number', input.value, field));
      });
    } else if (field.type === 'stringList') {
      input = document.createElement('input');
      input.type = 'text';
      input.placeholder = field.hint || '逗号分隔';
      input.value = Array.isArray(cur) ? cur.join(', ') : (cur ?? '');
      input.addEventListener('change', () => {
        commit(coerceValue('stringList', input.value, field));
      });
    } else if (field.type === 'materialMap') {
      input = document.createElement('input');
      input.type = 'text';
      input.placeholder = field.hint || 'iron:2, silk:1';
      input.value = formatMaterialMap(cur);
      input.addEventListener('change', () => {
        commit(coerceValue('materialMap', input.value, field));
      });
    } else {
      input = document.createElement('input');
      input.type = 'text';
      input.value = cur ?? '';
      input.placeholder = field.hint || '';
      if (field.datalist === 'coreAttackKeys' && SCHEMA.coreAttackKeys) {
        const listId = 'dl-core-attacks';
        let dl = document.getElementById(listId);
        if (!dl) {
          dl = document.createElement('datalist');
          dl.id = listId;
          for (const k of SCHEMA.coreAttackKeys) {
            const o = document.createElement('option');
            o.value = k;
            dl.append(o);
          }
          document.body.append(dl);
        }
        input.setAttribute('list', listId);
      }
      input.addEventListener('change', () => {
        commit(coerceValue('string', input.value, field));
      });
    }
    lab.append(input);
    if (field.presets && field.presets.length) {
      const row = document.createElement('div');
      row.className = 'preset-row';
      for (const pr of field.presets) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'preset-chip';
        b.textContent = pr.label;
        b.addEventListener('click', () => {
          setAt(obj, path, pr.value);
          onChange();
          // re-render so input shows new value
          if (typeof window.__designerRerenderGameplay === 'function') {
            window.__designerRerenderGameplay();
          }
        });
        row.append(b);
      }
      lab.append(row);
    }
    return lab;
  }

  function renderRecipeEditor(section) {
    renderSelect(section);
    const root = $(`#editor-${section}`);
    root.innerHTML = '';
    const list = state.content[section];
    if (!list.length) {
      root.innerHTML = '<div class="empty-recipe">尚无配方 · 点「新…」开卷，再自左侧点积木</div>';
      updatePreview(section);
      return;
    }
    const idx = Math.min(Math.max(0, state.sel[section]), list.length - 1);
    state.sel[section] = idx;
    const def = list[idx];
    const cfg = LIST_KEYS[section];

    renderDefFields(section, def, root);

    const listTitle = document.createElement('h3');
    listTitle.style.cssText = 'margin:1rem 0 0.5rem;font-size:0.85rem;letter-spacing:0.18em;color:var(--moon-soft)';
    listTitle.textContent = `${cfg.itemLabel}列表（点左侧积木追加）`;
    root.append(listTitle);

    const steps = def[cfg.listKey] || [];
    const stepList = document.createElement('div');
    stepList.className = 'step-list';

    if (!steps.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-recipe';
      empty.textContent = `尚无${cfg.itemLabel} · 自左侧白名单点入`;
      stepList.append(empty);
    }

    steps.forEach((step, si) => {
      const meta = kindMeta(section, step.kind);
      const card = document.createElement('div');
      card.className = 'step-card';
      const head = document.createElement('div');
      head.className = 'step-head';
      head.innerHTML = `<span class="step-kind">${step.kind}</span><span class="step-label">${meta?.label || ''}</span>`;
      const actions = document.createElement('div');
      actions.className = 'step-actions';
      const mkBtn = (label, fn) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = label;
        b.addEventListener('click', fn);
        return b;
      };
      actions.append(
        mkBtn('↑', () => {
          if (si === 0) return;
          [steps[si - 1], steps[si]] = [steps[si], steps[si - 1]];
          renderRecipeEditor(section);
        }),
        mkBtn('↓', () => {
          if (si >= steps.length - 1) return;
          [steps[si + 1], steps[si]] = [steps[si], steps[si + 1]];
          renderRecipeEditor(section);
        }),
        mkBtn('删', () => {
          steps.splice(si, 1);
          renderRecipeEditor(section);
          toast('已删积木');
        }),
      );
      head.append(actions);
      card.append(head);

      if (meta && meta.fields && meta.fields.length) {
        const fields = document.createElement('div');
        fields.className = 'step-fields';
        for (const f of meta.fields) {
          fields.append(renderFieldInput(f, step, () => {
            updatePreview(section);
            refreshExportPreview();
          }));
        }
        card.append(fields);
      }
      stepList.append(card);
    });

    root.append(stepList);
    updatePreview(section);
    refreshExportPreview();
  }

  function kindLabel(section, kind) {
    const m = kindMeta(section, kind);
    return (m && m.label) || kind;
  }

  function humanPreview(section, def) {
    if (!def) return '（还没有东西）';
    if (section === 'behaviors') {
      const steps = def.steps || [];
      const bits = steps.map((s) => {
        const lab = kindLabel('behaviors', s.kind);
        if (s.kind === 'keepDistance') return `保持约 ${s.idealMin ?? '?'}–${s.idealMax ?? '?'} 步距`;
        if (s.kind === 'meleeAttack') return `近处用「${s.attackKey || '默认'}」砍`;
        if (s.kind === 'rangedAttack') return `远处放「${s.projectileId || '箭'}」`;
        if (s.kind === 'dodge') return `贴身时${s.direction === 'side' ? '横跳' : '后撤'}闪身`;
        if (s.kind === 'circleStrafe') return `绕圈（半径约 ${s.radius ?? 130}）`;
        if (s.kind === 'flank') return s.preferBehind ? '抄到你身后' : '侧翼包抄';
        if (s.kind === 'callAlly') return `呼叫「${s.enemyId || '？'}」上场`;
        if (s.kind === 'phaseAtHp') return `气血低于 ${Math.round((s.below ?? 0) * 100)}% 进入「${s.setPhase || '?'}」`;
        if (s.kind === 'phaseGate') return `仅在「${s.phase}」阶段启用内招`;
        if (s.kind === 'comboChain') return `连斩：${(s.attackKeys || []).join(' → ') || '（空）'}`;
        if (s.kind === 'retreatBurst') return `急退约 ${s.dist ?? 90} 步`;
        if (s.kind === 'taunt') return `喝道「${s.text || '挑衅'}」`;
        if (s.kind === 'idleEmote') return `闲态「${s.text || '……'}」`;
        if (s.kind === 'useLoadout') return '使用随身外功/符/丹';
        if (s.kind === 'charge') return '直线冲锋';
        if (s.kind === 'block') return '举盾格挡';
        if (s.kind === 'facePlayer') return '始终盯着你';
        if (s.kind === 'idlePace') return '来回踱步';
        return lab;
      });
      const name = def.label || def.id || '这只敌人';
      return `<h3>这只敌人会…</h3><p class="hp-name">${name}</p><ul>${bits.map((b) => `<li>${b}</li>`).join('') || '<li>（尚未加招）</li>'}</ul>`;
    }
    if (section === 'silhouettes') {
      const parts = def.parts || [];
      const bits = parts.map((p) => {
        const lab = kindLabel('silhouettes', p.kind);
        if (p.kind === 'cloak') return `披风：${p.style || '长'}`;
        if (p.kind === 'armorLayer') return `甲片：${p.slot || '胸'}·${p.style || '轻'}`;
        if (p.kind === 'ornament') return `饰物：${p.slot || '腰'}·${p.style || ''}`;
        if (p.kind === 'faceMark') return `面记：${p.style || '无'}`;
        if (p.kind === 'stanceBias') return `站姿偏倾 ${p.lean ?? 0} / 蹲 ${p.crouch ?? 0}`;
        if (p.kind === 'headgear') return `头面：${p.style || '默认'}`;
        if (p.kind === 'mainhand') return p.fromWeapon ? '兵器跟装备走' : `兵器形：${p.shape || '自定义'}`;
        if (p.kind === 'palette') return '换了一身配色';
        if (p.kind === 'scale') return `体型 ×${p.value ?? 1}`;
        return lab;
      });
      return `<h3>长相一览</h3><p class="hp-name">${def.label || def.id}</p><ul>${bits.map((b) => `<li>${b}</li>`).join('') || '<li>（素颜骨架）</li>'}</ul>`;
    }
    if (section === 'weaponLooks') {
      const parts = def.parts || [];
      const bits = parts.map((p) => kindLabel('weaponLooks', p.kind) + (p.style ? `·${p.style}` : '') + (p.profile ? `·${p.profile}` : ''));
      return `<h3>这柄兵器</h3><p class="hp-name">${def.label || def.id}</p><p>基形 ${def.baseShape || '—'}</p><ul>${bits.map((b) => `<li>${b}</li>`).join('') || '<li>（空）</li>'}</ul>`;
    }
    if (section === 'animRecipes') {
      const steps = def.steps || [];
      return `<h3>招式样子</h3><p class="hp-name">${def.label || def.id}</p><ul>${steps.map((s) => `<li>${s.kind}${s.poseId ? ' · ' + s.poseId : ''}</li>`).join('') || '<li>（空）</li>'}</ul>`;
    }
    if (section === 'stages') {
      const arenas = def.arenas || [];
      const waves = arenas.map((a, i) => {
        const wcount = (a.waves || []).length;
        const types = (a.waves || []).flat().map((s) => s.type).filter(Boolean);
        const uniq = [...new Set(types)];
        return `第 ${i + 1} 场「${a.name || '?'}」：${wcount} 浪，来客 ${uniq.join('、') || '无'}${a.eliteWeight ? '（自带精英偏重）' : ''}`;
      });
      const boss = def.boss ? `Boss「${def.boss.bossName || def.boss.bossId}」· 气血×${def.boss.hpScale ?? 1}` : '尚无 Boss';
      return `<h3>这一浪会出…</h3><p class="hp-name">${def.title || def.id}</p><ul>${waves.map((w) => `<li>${w}</li>`).join('')}<li>${boss}</li></ul>`;
    }
    if (section === 'gameplay') {
      const kind = state.gpKind;
      if (kind === 'enemies') {
        const col = def.colliderId
          || (def.collider ? `内联 ${def.collider.w}×${def.collider.h}` : null);
        return `<h3>这只敌寇</h3><p class="hp-name">${def.name || def.id}</p><ul>
          <li>碰撞：${col || '—'}</li>
          <li>长相：${def.silhouetteId || '—'}</li>
          <li>怎么打：${def.behaviorId || '—'}</li>
          <li>气血：${def.hp ?? '—'}</li>
          <li>机体别名（兼容）：${def.body || '—'}</li>
        </ul>`;
      }
      if (kind === 'weapons') {
        const feel = def.feel && def.feel.boxTune
          ? `tipXPush=${def.feel.boxTune.tipXPush ?? '—'} · tipWFloorMul=${def.feel.boxTune.tipWFloorMul ?? '—'}`
          : '（无 boxTune）';
        const look = def.lookId
          ? `外观 ${def.lookId}${(state.content.weaponLooks || []).some((x) => x.id === def.lookId) ? '（本卷已有）' : '（需本卷或长夜登记）'}`
          : (def.parts && def.parts.length ? `内联 parts ×${def.parts.length}` : '无外观配方（回退形/色）');
        return `<h3>这柄兵刃</h3><p class="hp-name">${def.name || def.id}</p><ul>
          <li>类别 ${def.category || '—'} · 形 ${def.shape || '—'} · 重量 ${def.weight || '—'}</li>
          <li>${look}</li>
          <li>数值 伤${def.damage ?? '—'} / 速${def.speed ?? '—'} / 触${def.reach ?? '—'}</li>
          <li>克制 ${(def.affinities || []).join('、') || '—'}（+${def.affinityBonus ?? 0}）</li>
          <li>手感 ${feel}</li>
          <li>解锁 ${(def.unlock && def.unlock.type) || '—'} ${(def.unlock && def.unlock.hint) || ''}</li>
        </ul>`;
      }
      if (kind === 'skills') {
        return `<h3>这门外功</h3><p class="hp-name">${def.name || def.id}</p><ul>
          <li>${def.kind || '—'} · ${def.castKind || '（无施放）'}</li>
          <li>攻击盒 <code>${def.attackKey || '—'}</code>（须在 ctx.attacks）</li>
          <li>门控 ${def.weaponGate || '—'}</li>
          <li>内力 ${def.neiliCost ?? '—'} · 品质 ${def.quality || '—'}</li>
          <li>${def.tip || ''}</li>
        </ul>`;
      }
      return `<h3>${def.name || def.id}</h3><p class="muted">编号 ${def.id}</p>`;
    }
    return `<pre class="mini-json">${escapeHtml(JSON.stringify(def, null, 2))}</pre>`;
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function paintPreview(section, def, extra) {
    const box = $(`#preview-${section}`);
    if (!box) return;
    let host = box.querySelector('.ink-preview-host');
    let text = box.querySelector('.human-text');
    if (!host || !text) {
      box.innerHTML = '';
      host = document.createElement('div');
      host.className = 'ink-preview-host';
      text = document.createElement('div');
      text.className = 'human-text';
      box.append(host, text);
    }
    text.innerHTML = humanPreview(section, def);
    if (window.DesignerPreview && typeof window.DesignerPreview.render === 'function') {
      const opts = Object.assign({ content: state.content }, extra || {});
      window.DesignerPreview.render(host, section, def, opts);
    } else {
      host.innerHTML = '<p class="muted">（预览脚本未载入）</p>';
    }
  }

  function updatePreview(section) {
    const list = state.content[section];
    const def = list && list[state.sel[section]];
    paintPreview(section, def);
  }

  /* ── Gameplay ──────────────────────────────────────────── */

  function gameplayFields(kind) {
    if (kind === 'weapons' && SCHEMA.weapons && Array.isArray(SCHEMA.weapons.defFields)) {
      return SCHEMA.weapons.defFields.map((f) => {
        const copy = { ...f };
        if (copy.key === 'lookId') {
          copy.type = 'enum';
          copy.enum = (state.content.weaponLooks || []).map((x) => x.id).filter(Boolean);
        }
        if (copy.key === 'affinities' && SCHEMA.affinities) {
          copy.hint = '闭集：' + SCHEMA.affinities.join(' / ');
        }
        return copy;
      });
    }
    if (kind === 'skills' && SCHEMA.skills && Array.isArray(SCHEMA.skills.defFields)) {
      return SCHEMA.skills.defFields.map((f) => ({ ...f }));
    }
    if (kind === 'weapons') {
      return [
        { key: 'id', type: 'string', label: '编号（可改）', required: true },
        { key: 'name', type: 'string', label: '名称', required: true },
        { key: 'category', type: 'enum', enum: SCHEMA.weaponCategories || ['bare', 'blade', 'spear', 'heavy'], label: '类别' },
        { key: 'shape', type: 'enum', enum: SCHEMA.bladeShapes, label: '形' },
        { key: 'weight', type: 'enum', enum: SCHEMA.weaponWeights || ['light', 'medium', 'heavy'], label: '重量档' },
        { key: 'length', type: 'number', label: '长度' },
        { key: 'blade', type: 'color', label: '刃色' },
        { key: 'trail', type: 'color', label: '拖影' },
        { key: 'edge', type: 'color', label: '刃锋' },
        { key: 'lookId', type: 'enum', enum: (state.content.weaponLooks || []).map((x) => x.id).filter(Boolean), label: '兵器长相编号' },
        { key: 'feel.boxTune.tipXPush', type: 'number', label: '手感·枪尖前推' },
      ];
    }
    if (kind === 'skills') {
      return [
        { key: 'id', type: 'string', label: '编号（可改）', required: true },
        { key: 'name', type: 'string', label: '名称', required: true },
        { key: 'tip', type: 'string', label: '提示' },
        { key: 'castKind', type: 'enum', enum: SCHEMA.skillCastKinds || ['attack'], label: '施放类型' },
        { key: 'attackKey', type: 'string', label: '攻击盒编号', datalist: 'coreAttackKeys' },
        { key: 'weaponGate', type: 'enum', enum: SCHEMA.weaponGates || ['any'], label: '兵器门控' },
        { key: 'castAnim', type: 'string', label: '招式样子编号' },
        { key: 'quality', type: 'enum', enum: SCHEMA.inherentQualities || ['fan'], label: '品质' },
      ];
    }
    if (kind === 'talismans') {
      return [
        { key: 'id', type: 'string', label: '编号（可改）' },
        { key: 'name', type: 'string', label: '名称' },
        { key: 'tip', type: 'string', label: '提示' },
        { key: 'color', type: 'color', label: '色' },
        { key: 'anim', type: 'string', label: 'anim（动画配方 id）' },
        { key: 'scriptId', type: 'string', label: '符效果编号' },
        { key: 'fee', type: 'number', label: '费用' },
        { key: 'quality', type: 'string', label: '品质' },
        { key: 'grade', type: 'string', label: '品级' },
      ];
    }
    if (kind === 'enemies') {
      return [
        { key: 'id', type: 'string', label: '编号（可改）' },
        { key: 'name', type: 'string', label: '名称' },
        { key: 'body', type: 'enum', enum: SCHEMA.bodies.map((b) => b.id), label: '机体' },
        { key: 'hp', type: 'number', label: '气血' },
        { key: 'silhouetteId', type: 'string', label: '长相编号' },
        { key: 'behaviorId', type: 'string', label: '打法编号' },
        { key: 'dropChance', type: 'number', label: '掉落率' },
      ];
    }
    return [];
  }

  function renderGameplay() {
    const kind = state.gpKind;
    const list = state.content[kind];
    const sel = $('#sel-gp-item') || $('#sel-gameplay');
    if (!sel) return;
    sel.innerHTML = '';
    if (!list.length) {
      const o = document.createElement('option');
      o.textContent = '（空）';
      o.value = '-1';
      sel.append(o);
    } else {
      list.forEach((d, i) => {
        const o = document.createElement('option');
        o.value = String(i);
        o.textContent = `${d.id || '?'}${d.name ? ' · ' + d.name : ''}`;
        if (i === state.gpSel) o.selected = true;
        sel.append(o);
      });
    }

    const root = $('#editor-gameplay');
    root.innerHTML = '';
    if (!list.length) {
      root.innerHTML = '<div class="empty-recipe">此类尚无条目</div>';
      paintPreview('gameplay', null, { gpKind: kind });
      return;
    }
    state.gpSel = Math.min(state.gpSel, list.length - 1);
    const def = list[state.gpSel];
    const grid = document.createElement('div');
    grid.className = 'form-grid';
    for (const f of gameplayFields(kind)) {
      const fake = { ...f, key: f.key };
      // reuse renderer but need label override
      const node = renderFieldInput(fake, def, () => {
        renderGameplaySelectOnly();
        refreshExportPreview();
      });
      node.querySelector('span').textContent = f.label || f.key;
      grid.append(node);
    }
    root.append(grid);
    paintPreview('gameplay', def, { gpKind: kind });
    window.__designerRerenderGameplay = () => renderGameplay();
  }

  function renderGameplaySelectOnly() {
    const kind = state.gpKind;
    const list = state.content[kind];
    const sel = $('#sel-gp-item') || $('#sel-gameplay');
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '';
    list.forEach((d, i) => {
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = `${d.id || '?'}${d.name ? ' · ' + d.name : ''}`;
      if (String(i) === cur || i === state.gpSel) o.selected = true;
      sel.append(o);
    });
  }


  /* ── Stages / 关卡导演 ─────────────────────────────────── */

  function enemyTypeOptions() {
    const builtins = ['axe', 'shield', 'archer', 'spear', 'gargoyle'];
    const fromPack = (state.content.enemies || []).map((e) => e.id).filter(Boolean);
    const seen = new Set();
    const out = [];
    for (const id of [...builtins, ...fromPack]) {
      if (!id || seen.has(id)) continue;
      seen.add(id);
      out.push(id);
    }
    return out;
  }

  function emptySpawn() {
    const opts = enemyTypeOptions();
    return { type: opts.includes('axe') ? 'axe' : (opts[0] || 'axe'), side: 'R', delay: 0 };
  }

  function emptyArena(n = 0) {
    return {
      name: `场地${n + 1}`,
      x0: 520 + n * 1400,
      trigger: 860 + n * 1400,
      waves: [[emptySpawn()], [emptySpawn()]],
    };
  }

  function emptyBoss() {
    return {
      name: '决战关口',
      x0: 4760,
      trigger: 5040,
      bossName: '无名石兽',
      bossSubtitle: '石影苏醒',
      bossId: 'gargoyle',
      hpScale: 1,
      dmgScale: 1,
      tint: 'jade',
    };
  }

  function emptyStage() {
    const n = state.content.stages.length;
    return {
      id: `act_custom_${Date.now().toString(36).slice(-4)}`,
      actIndex: n,
      title: `第${n + 1}幕 · 未名`,
      subtitle: '纸上新关',
      length: 5800,
      start: 220,
      backdropTheme: 'night',
      arenas: [emptyArena(0), emptyArena(1)],
      boss: emptyBoss(),
      platforms: [],
      beats: [],
    };
  }

  function ensureStageShape(st) {
    if (!Array.isArray(st.arenas)) st.arenas = [];
    if (!st.boss || typeof st.boss !== 'object') st.boss = emptyBoss();
    if (!Array.isArray(st.platforms)) st.platforms = [];
    if (!Array.isArray(st.beats)) st.beats = [];
    for (const a of st.arenas) {
      if (!Array.isArray(a.waves)) a.waves = [[]];
      a.waves = a.waves.map((w) => (Array.isArray(w) ? w : []));
    }
  }

  function bindNum(input, obj, key, onChange) {
    input.type = 'number';
    input.step = 'any';
    input.value = obj[key] != null ? obj[key] : '';
    input.addEventListener('change', () => {
      const v = coerceValue('number', input.value, {});
      if (v === undefined) delete obj[key];
      else obj[key] = v;
      onChange();
    });
  }

  function bindText(input, obj, key, onChange) {
    input.type = 'text';
    input.value = obj[key] ?? '';
    input.addEventListener('change', () => {
      const v = String(input.value || '').trim();
      if (!v && key !== 'subtitle' && key !== 'bossSubtitle' && key !== 'backdropTheme') {
        /* keep required-ish as empty string for export clarity */
      }
      obj[key] = input.value;
      onChange();
    });
  }

  function mkField(labelText, inputEl) {
    const lab = document.createElement('label');
    lab.className = 'field';
    const span = document.createElement('span');
    span.textContent = labelText;
    lab.append(span, inputEl);
    return lab;
  }

  function enemyTypeSelect(cur, onPick) {
    const sel = document.createElement('select');
    const opts = enemyTypeOptions();
    if (cur && !opts.includes(cur)) {
      const o = document.createElement('option');
      o.value = cur;
      o.textContent = `${cur}（自填）`;
      o.selected = true;
      sel.append(o);
    }
    for (const id of opts) {
      const o = document.createElement('option');
      o.value = id;
      o.textContent = id;
      if (id === cur) o.selected = true;
      sel.append(o);
    }
    const custom = document.createElement('option');
    custom.value = '__custom__';
    custom.textContent = '…自填';
    sel.append(custom);
    sel.addEventListener('change', () => {
      if (sel.value === '__custom__') {
        const v = prompt('敌寇 type / id', cur || '');
        if (v != null && v.trim()) onPick(v.trim());
        else onPick(cur || 'axe');
        return;
      }
      onPick(sel.value);
    });
    return sel;
  }

  function renderStages() {
    const sel = $('#sel-stages');
    const root = $('#editor-stages');
    if (!sel || !root) return;
    const list = state.content.stages;
    sel.innerHTML = '';
    if (!list.length) {
      const o = document.createElement('option');
      o.value = '-1';
      o.textContent = '（尚无幕次）';
      sel.append(o);
      root.innerHTML = '<div class="empty-recipe">尚无幕次 · 点「新幕」或「载入骨架」</div>';
      refreshExportPreview();
      paintPreview('stages', null);
      return;
    }
    list.forEach((d, i) => {
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = `${d.id || '?'} · ${d.title || ''}（act ${d.actIndex ?? i}）`;
      if (i === state.stageSel) o.selected = true;
      sel.append(o);
    });
    state.stageSel = Math.min(Math.max(0, state.stageSel), list.length - 1);
    const st = list[state.stageSel];
    ensureStageShape(st);
    root.innerHTML = '';

    const redraw = () => {
      renderStages();
      refreshExportPreview();
    };

    /* meta */
    const meta = document.createElement('div');
    meta.className = 'form-grid';
    const metaFields = [
      ['id', '幕号 id', 'text'],
      ['actIndex', '幕序 actIndex', 'number'],
      ['title', '标题', 'text'],
      ['subtitle', '副标题', 'text'],
      ['length', '关长 length', 'number'],
      ['start', '起点 start', 'number'],
      ['backdropTheme', '背景 theme', 'theme'],
    ];
    for (const [key, label, typ] of metaFields) {
      if (typ === 'theme') {
        const input = document.createElement('input');
        input.type = 'text';
        input.setAttribute('list', 'backdrop-theme-list');
        input.placeholder = 'night|dock|ash|eclipse';
        input.value = st[key] ?? '';
        input.addEventListener('change', () => { st[key] = input.value; redraw(); });
        meta.append(mkField(label, input));
      } else if (typ === 'number') {
        const input = document.createElement('input');
        bindNum(input, st, key, () => { renderStagesSelectOnly(); refreshExportPreview(); });
        meta.append(mkField(label, input));
      } else {
        const input = document.createElement('input');
        bindText(input, st, key, () => { renderStagesSelectOnly(); refreshExportPreview(); });
        meta.append(mkField(label, input));
      }
    }
    let dl = $('#backdrop-theme-list');
    if (!dl) {
      dl = document.createElement('datalist');
      dl.id = 'backdrop-theme-list';
      for (const t of (SCHEMA.stages?.backdropThemes || ['night', 'dock', 'ash', 'eclipse'])) {
        const o = document.createElement('option');
        o.value = t;
        dl.append(o);
      }
      document.body.append(dl);
    }
    root.append(meta);

    /* arenas */
    const arenasHead = document.createElement('div');
    arenasHead.className = 'stage-section-head';
    arenasHead.innerHTML = '<h3>Arenas · 浪次</h3>';
    const addArena = document.createElement('button');
    addArena.type = 'button';
    addArena.className = 'btn-ink';
    addArena.textContent = '＋ 场地';
    addArena.addEventListener('click', () => {
      st.arenas.push(emptyArena(st.arenas.length));
      redraw();
      toast('已加场地');
    });
    arenasHead.append(addArena);
    root.append(arenasHead);

    st.arenas.forEach((arena, ai) => {
      const card = document.createElement('div');
      card.className = 'step-card stage-arena';
      const head = document.createElement('div');
      head.className = 'step-head';
      head.innerHTML = `<span class="step-kind">场地 ${ai + 1}</span><span class="step-label">${arena.name || ''}</span>`;
      const actions = document.createElement('div');
      actions.className = 'step-actions';
      const delA = document.createElement('button');
      delA.type = 'button';
      delA.textContent = '删场地';
      delA.addEventListener('click', () => {
        st.arenas.splice(ai, 1);
        redraw();
      });
      actions.append(delA);
      head.append(actions);
      card.append(head);

      const aGrid = document.createElement('div');
      aGrid.className = 'form-grid';
      for (const [key, label, typ] of [['name', '名称', 'text'], ['x0', 'x0', 'number'], ['trigger', 'trigger', 'number']]) {
        const input = document.createElement('input');
        if (typ === 'number') bindNum(input, arena, key, () => refreshExportPreview());
        else bindText(input, arena, key, () => { renderStagesSelectOnly(); refreshExportPreview(); });
        aGrid.append(mkField(label, input));
      }
      card.append(aGrid);

      const wavesWrap = document.createElement('div');
      wavesWrap.className = 'stage-waves';
      const wToolbar = document.createElement('div');
      wToolbar.className = 'recipe-toolbar';
      const wTitle = document.createElement('span');
      wTitle.className = 'stage-sublabel';
      wTitle.textContent = '浪次 waves[][]';
      const addWave = document.createElement('button');
      addWave.type = 'button';
      addWave.className = 'btn-ink';
      addWave.textContent = '＋ 浪';
      addWave.addEventListener('click', () => {
        if (!Array.isArray(arena.waves)) arena.waves = [];
        arena.waves.push([emptySpawn()]);
        redraw();
      });
      wToolbar.append(wTitle, addWave);
      wavesWrap.append(wToolbar);

      (arena.waves || []).forEach((wave, wi) => {
        const wCard = document.createElement('div');
        wCard.className = 'stage-wave';
        const wh = document.createElement('div');
        wh.className = 'step-head';
        wh.innerHTML = `<span class="step-kind">浪 ${wi + 1}</span>`;
        const wa = document.createElement('div');
        wa.className = 'step-actions';
        const addSpawn = document.createElement('button');
        addSpawn.type = 'button';
        addSpawn.textContent = '＋ Spawn';
        addSpawn.addEventListener('click', () => {
          wave.push(emptySpawn());
          redraw();
        });
        const delWave = document.createElement('button');
        delWave.type = 'button';
        delWave.textContent = '删浪';
        delWave.addEventListener('click', () => {
          arena.waves.splice(wi, 1);
          redraw();
        });
        wa.append(addSpawn, delWave);
        wh.append(wa);
        wCard.append(wh);

        const table = document.createElement('div');
        table.className = 'stage-spawn-table';
        wave.forEach((sp, si) => {
          const row = document.createElement('div');
          row.className = 'stage-spawn-row';
          const typeSel = enemyTypeSelect(sp.type, (v) => {
            sp.type = v;
            redraw();
          });
          const sideSel = document.createElement('select');
          for (const s of ['L', 'R']) {
            const o = document.createElement('option');
            o.value = s;
            o.textContent = s;
            if (sp.side === s) o.selected = true;
            sideSel.append(o);
          }
          sideSel.addEventListener('change', () => {
            sp.side = sideSel.value;
            refreshExportPreview();
          });
          const delay = document.createElement('input');
          bindNum(delay, sp, 'delay', () => refreshExportPreview());
          delay.title = 'delay';
          const del = document.createElement('button');
          del.type = 'button';
          del.textContent = '删';
          del.addEventListener('click', () => {
            wave.splice(si, 1);
            redraw();
          });
          row.append(
            mkField('type', typeSel),
            mkField('side', sideSel),
            mkField('delay', delay),
            del,
          );
          table.append(row);
        });
        wCard.append(table);
        wavesWrap.append(wCard);
      });
      card.append(wavesWrap);
      root.append(card);
    });

    /* boss */
    const bossHead = document.createElement('div');
    bossHead.className = 'stage-section-head';
    bossHead.innerHTML = '<h3>Boss 遭遇</h3>';
    root.append(bossHead);
    const bossGrid = document.createElement('div');
    bossGrid.className = 'form-grid';
    const boss = st.boss;
    const bossFields = [
      ['name', '关口名', 'text'],
      ['x0', 'x0', 'number'],
      ['trigger', 'trigger', 'number'],
      ['bossName', 'Boss 名', 'text'],
      ['bossSubtitle', 'Boss 副标', 'text'],
      ['bossId', 'bossId', 'enemy'],
      ['hpScale', '气血倍率', 'number'],
      ['dmgScale', '伤害倍率', 'number'],
      ['tint', '染色', 'tint'],
    ];
    for (const [key, label, typ] of bossFields) {
      if (typ === 'enemy') {
        bossGrid.append(mkField(label, enemyTypeSelect(boss[key], (v) => {
          boss[key] = v;
          redraw();
        })));
      } else if (typ === 'tint') {
        const sel = document.createElement('select');
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = '—';
        sel.append(empty);
        for (const t of (SCHEMA.stages?.bossTints || ['jade', 'ink', 'blood', 'ash'])) {
          const o = document.createElement('option');
          o.value = t;
          o.textContent = t;
          if (boss.tint === t) o.selected = true;
          sel.append(o);
        }
        sel.addEventListener('change', () => {
          if (!sel.value) delete boss.tint;
          else boss.tint = sel.value;
          refreshExportPreview();
        });
        bossGrid.append(mkField(label, sel));
      } else if (typ === 'number') {
        const input = document.createElement('input');
        bindNum(input, boss, key, () => refreshExportPreview());
        bossGrid.append(mkField(label, input));
      } else {
        const input = document.createElement('input');
        bindText(input, boss, key, () => refreshExportPreview());
        bossGrid.append(mkField(label, input));
      }
    }
    root.append(bossGrid);

    /* platforms */
    const platHead = document.createElement('div');
    platHead.className = 'stage-section-head';
    platHead.innerHTML = '<h3>Platforms · 平台</h3>';
    const addPlat = document.createElement('button');
    addPlat.type = 'button';
    addPlat.className = 'btn-ink';
    addPlat.textContent = '＋ 平台';
    addPlat.addEventListener('click', () => {
      st.platforms.push({ x: 580, y: 372, w: 170, h: 96, kind: 'roof' });
      redraw();
    });
    platHead.append(addPlat);
    root.append(platHead);

    const platTable = document.createElement('div');
    platTable.className = 'stage-plat-table';
    if (!st.platforms.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-recipe';
      empty.textContent = '无平台 · 载入骨架可带核心几何，或手工增行';
      platTable.append(empty);
    }
    st.platforms.forEach((pl, pi) => {
      const row = document.createElement('div');
      row.className = 'stage-spawn-row';
      for (const key of ['x', 'y', 'w', 'h']) {
        const input = document.createElement('input');
        bindNum(input, pl, key, () => refreshExportPreview());
        row.append(mkField(key, input));
      }
      const kindSel = document.createElement('select');
      const emptyK = document.createElement('option');
      emptyK.value = '';
      emptyK.textContent = '—';
      kindSel.append(emptyK);
      for (const k of (SCHEMA.stages?.platformKinds || ['roof', 'bridge', 'pavilion'])) {
        const o = document.createElement('option');
        o.value = k;
        o.textContent = k;
        if (pl.kind === k) o.selected = true;
        kindSel.append(o);
      }
      kindSel.addEventListener('change', () => {
        if (!kindSel.value) delete pl.kind;
        else pl.kind = kindSel.value;
        refreshExportPreview();
      });
      row.append(mkField('kind', kindSel));
      const del = document.createElement('button');
      del.type = 'button';
      del.textContent = '删';
      del.addEventListener('click', () => {
        st.platforms.splice(pi, 1);
        redraw();
      });
      row.append(del);
      platTable.append(row);
    });
    root.append(platTable);

    const beatsNote = document.createElement('p');
    beatsNote.className = 'hint';
    beatsNote.textContent = 'beats 叙事默认 []（可于导出 JSON 手工补）；本台以浪次与 Boss 为主。';
    root.append(beatsNote);

    paintPreview('stages', st);
    refreshExportPreview();
  }

  function renderStagesSelectOnly() {
    const sel = $('#sel-stages');
    if (!sel) return;
    const list = state.content.stages;
    const cur = String(state.stageSel);
    sel.innerHTML = '';
    list.forEach((d, i) => {
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = `${d.id || '?'} · ${d.title || ''}（act ${d.actIndex ?? i}）`;
      if (String(i) === cur) o.selected = true;
      sel.append(o);
    });
  }

  /* ── IO ────────────────────────────────────────────────── */

  function refreshExportPreview() {
    const pre = $('#export-preview');
    if (!pre) return;
    pre.textContent = JSON.stringify(buildUploadPayload(), null, 2);
  }

  function importPayload(obj) {
    if (!obj || typeof obj !== 'object') throw new Error('非对象');
    let pack = obj.pack;
    let content = obj.content;
    // raw pack.json shape
    if (!pack && obj.id && (obj.kind === 'pack' || obj.kind === 'menpai')) {
      pack = obj;
      content = {};
    }
    // raw content-only
    if (!pack && !content && (obj.weaponLooks || obj.talismans || obj.enemies || obj.animRecipes || obj.stages)) {
      content = obj;
      pack = null;
    }
    if (pack) {
      state.pack = {
        id: pack.id || state.pack.id,
        kind: pack.kind === 'menpai' ? 'menpai' : 'pack',
        name: pack.name || '',
        version: pack.version || '0.1.0',
        description: pack.description || '',
        tags: Array.isArray(pack.tags) ? pack.tags.slice() : [],
        builtin: Boolean(pack.builtin),
      };
    }
    if (content && typeof content === 'object') {
      for (const k of Object.keys(state.content)) {
        if (Array.isArray(content[k])) state.content[k] = deepClone(content[k]);
      }
    }
    // reset selections
    for (const k of Object.keys(state.sel)) state.sel[k] = 0;
    state.gpSel = 0;
    state.stageSel = 0;
    renderMeta();
    for (const s of Object.keys(LIST_KEYS)) renderRecipeEditor(s);
    renderGameplay();
    renderStages();
    refreshExportPreview();
    toast('已回填设计台');
  }

  /* ── Wire UI ───────────────────────────────────────────── */

  function showWorkbench(show) {
    const home = $('#wizard-home');
    const tabs = $('#designer-tabs');
    const main = $('#designer-main');
    if (home) home.hidden = !!show;
    if (tabs) tabs.hidden = !show;
    if (main) main.hidden = !show;
  }

  function switchPanel(name) {
    if (name === 'home') {
      showWorkbench(false);
      return;
    }
    showWorkbench(true);
    $$('.designer-tabs .tab').forEach((t) => {
      const on = t.dataset.panel === name;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $$('.panel').forEach((p) => {
      const on = p.id === `panel-${name}`;
      p.classList.toggle('active', on);
      p.hidden = !on;
    });
  }

  function runWizard(kind) {
    if (kind === 'enemy') {
      // ensure linked silhouette + behavior + enemy
      if (!state.content.silhouettes.length) {
        state.content.silhouettes.push(emptyDef('silhouettes'));
        state.content.silhouettes[0].label = '新敌长相';
      }
      if (!state.content.behaviors.length) {
        state.content.behaviors.push(emptyDef('behaviors'));
        state.content.behaviors[0].label = '新敌打法';
        state.content.behaviors[0].steps = [
          { kind: 'keepDistance', idealMin: 80, idealMax: 150, chase: 220 },
          { kind: 'meleeAttack', attackKey: 'thrust', rangeMax: 160, weight: 2 },
          { kind: 'facePlayer' },
        ];
      }
      if (!state.content.enemies.length) {
        const sil = state.content.silhouettes[0];
        const beh = state.content.behaviors[0];
        state.content.enemies.push({
          id: `enemy_${Date.now().toString(36).slice(-5)}`,
          name: '未名敌寇',
          body: sil.body || 'spear',
          hp: 60,
          silhouetteId: sil.id,
          behaviorId: beh.id,
          dropChance: 0.2,
          eliteEligible: true,
        });
      }
      state.sel.silhouettes = 0;
      state.sel.behaviors = 0;
      state.gpKind = 'enemies';
      state.gpSel = 0;
      renderRecipeEditor('silhouettes');
      renderRecipeEditor('behaviors');
      renderGameplay();
      switchPanel('behaviors');
      toast('已备好敌寇草稿：先调「怎么打」，再去长相/玩法目录');
      return;
    }
    if (kind === 'weapon') {
      if (!state.content.weaponLooks.length) {
        state.content.weaponLooks.push(emptyDef('weaponLooks'));
        state.content.weaponLooks[0].label = '新兵刃长相';
        state.content.weaponLooks[0].parts = [
          { kind: 'palette', blade: '#c8d0e8', trail: '#7090c0', edge: '#e8f0ff', grip: '#2a2430' },
          { kind: 'grip', length: 9, width: 3 },
          { kind: 'guard', style: 'cross', width: 10 },
          { kind: 'blade', profile: 'curved', lengthFrac: 1 },
          { kind: 'tip', style: 'point' },
          { kind: 'inkEdge' },
        ];
      }
      if (!state.content.weapons.length) {
        const w = emptyGameplay('weapons');
        w.lookId = state.content.weaponLooks[0].id;
        state.content.weapons.push(w);
      } else if (!state.content.weapons[0].lookId) {
        state.content.weapons[0].lookId = state.content.weaponLooks[0].id;
      }
      if (!state.content.skills.length) {
        state.content.skills.push(emptyGameplay('skills'));
      }
      state.sel.weaponLooks = 0;
      state.gpKind = 'weapons';
      state.gpSel = 0;
      renderRecipeEditor('weaponLooks');
      renderGameplay();
      switchPanel('weaponLooks');
      toast('已备兵刃草稿：先调「兵器长相」，再去玩法目录挂 lookId / 外功 attackKey');
      return;
    }
    if (kind === 'moves') {
      if (!state.content.animRecipes.length) {
        state.content.animRecipes.push(emptyDef('animRecipes'));
      }
      switchPanel('animRecipes');
      toast('可做招式样子；兵器长相、符在玩法目录');
      return;
    }
    if (kind === 'stage') {
      if (!state.content.stages.length) {
        state.content.stages.push(emptyStage());
      }
      state.stageSel = 0;
      renderStages();
      switchPanel('stages');
      toast('开始排浪次');
    }
  }

  function wire() {
    $$('.designer-tabs .tab').forEach((tab) => {
      tab.addEventListener('click', () => switchPanel(tab.dataset.panel));
    });
    $$('.wizard-card').forEach((btn) => {
      btn.addEventListener('click', () => runWizard(btn.dataset.wizard));
    });
    $$('[data-goto]').forEach((btn) => {
      btn.addEventListener('click', () => switchPanel(btn.dataset.goto));
    });
    $('#btn-toggle-json')?.addEventListener('click', () => {
      const pre = $('#export-preview');
      if (!pre) return;
      pre.hidden = !pre.hidden;
      if (!pre.hidden) refreshExportPreview();
    });

    for (const section of Object.keys(LIST_KEYS)) {
      $(`[data-add-recipe="${section}"]`)?.addEventListener('click', () => {
        state.content[section].push(emptyDef(section));
        state.sel[section] = state.content[section].length - 1;
        renderRecipeEditor(section);
        toast('已开新配方');
      });
      $(`[data-del-recipe="${section}"]`)?.addEventListener('click', () => {
        const list = state.content[section];
        if (!list.length) return;
        list.splice(state.sel[section], 1);
        state.sel[section] = Math.max(0, state.sel[section] - 1);
        renderRecipeEditor(section);
        toast('已删配方');
      });
      $(`#sel-${section}`)?.addEventListener('change', (e) => {
        state.sel[section] = Number(e.target.value) || 0;
        renderRecipeEditor(section);
      });
    }

    $('#sel-gp-kind')?.addEventListener('change', (e) => {
      state.gpKind = e.target.value;
      state.gpSel = 0;
      renderGameplay();
    });
    $('#btn-gp-add')?.addEventListener('click', () => {
      state.content[state.gpKind].push(emptyGameplay(state.gpKind));
      state.gpSel = state.content[state.gpKind].length - 1;
      renderGameplay();
    });
    $('#btn-gp-del')?.addEventListener('click', () => {
      const list = state.content[state.gpKind];
      if (!list.length) return;
      list.splice(state.gpSel, 1);
      state.gpSel = Math.max(0, state.gpSel - 1);
      renderGameplay();
    });
    $('#sel-gp-item')?.addEventListener('change', (e) => {
      state.gpSel = Number(e.target.value) || 0;
      renderGameplay();
    });
    // legacy ids if present
    $('#gp-add')?.addEventListener('click', () => $('#btn-gp-add')?.click());
    $('#sel-gameplay')?.addEventListener('change', (e) => {
      state.gpSel = Number(e.target.value) || 0;
      renderGameplay();
    });


    $('#btn-stage-add')?.addEventListener('click', () => {
      state.content.stages.push(emptyStage());
      state.stageSel = state.content.stages.length - 1;
      renderStages();
      toast('已开新幕');
    });
    $('#btn-stage-del')?.addEventListener('click', () => {
      const list = state.content.stages;
      if (!list.length) return;
      list.splice(state.stageSel, 1);
      state.stageSel = Math.max(0, state.stageSel - 1);
      renderStages();
      toast('已删幕');
    });
    $('#sel-stages')?.addEventListener('change', (e) => {
      state.stageSel = Number(e.target.value) || 0;
      renderStages();
    });
    $('#stage-load-skel')?.addEventListener('click', async () => {
      const key = $('#stage-skeleton')?.value;
      if (!key) { toast('先选 act1–4'); return; }
      try {
        if (!STAGE_SKELS) {
          const res = await fetch('/assets/stage-skeletons.json', { cache: 'no-store' });
          if (!res.ok) throw new Error(`骨架 ${res.status}`);
          STAGE_SKELS = await res.json();
        }
        const sk = STAGE_SKELS[key];
        if (!sk) throw new Error(`无 ${key}`);
        const clone = deepClone(sk);
        // if editing existing, replace in place; else push
        if (state.content.stages.length && state.stageSel >= 0 && state.stageSel < state.content.stages.length) {
          state.content.stages[state.stageSel] = clone;
        } else {
          state.content.stages.push(clone);
          state.stageSel = state.content.stages.length - 1;
        }
        // suggest stage tag
        if (!state.pack.tags.includes('stage')) state.pack.tags.push('stage');
        renderMeta();
        renderStages();
        toast(`已载入 ${key} 骨架 · 可改浪次/Boss`);
      } catch (err) {
        toast(`载入失败：${err.message || err}`);
      }
    });

    $('#btn-dl-pack')?.addEventListener('click', () => {
      const p = buildPackExport();
      if (!ID_RE.test(p.id)) { toast('卷号不合规'); return; }
      downloadJson('pack.json', p);
    });
    $('#btn-dl-content')?.addEventListener('click', () => {
      downloadJson('content.json', buildContentExport());
    });
    $('#btn-dl-both')?.addEventListener('click', () => {
      const p = buildPackExport();
      if (!ID_RE.test(p.id)) { toast('卷号不合规'); return; }
      downloadJson(`${p.id}-pack.json`, p);
      downloadJson(`${p.id}-content.json`, buildContentExport());
    });
    $('#btn-copy-upload')?.addEventListener('click', async () => {
      const text = JSON.stringify(buildUploadPayload(), null, 2);
      try {
        await navigator.clipboard.writeText(text);
        toast('已复制入藏 JSON');
      } catch {
        $('#import-text').value = text;
        toast('剪贴板不可用，已写入导入框');
      }
    });

    const tokenInput = $('#upload-token');
    if (tokenInput) {
      tokenInput.value = sessionStorage.getItem(TOKEN_KEY) || '';
      tokenInput.addEventListener('change', () => {
        sessionStorage.setItem(TOKEN_KEY, tokenInput.value.trim());
      });
    }
    $('#btn-upload')?.addEventListener('click', async () => {
      const token = ($('#upload-token')?.value || '').trim();
      const status = $('#upload-status');
      if (!token) {
        status.textContent = '请先填入令牌（本页 sessionStorage）。';
        return;
      }
      sessionStorage.setItem(TOKEN_KEY, token);
      const payload = buildUploadPayload();
      if (!ID_RE.test(payload.pack.id)) {
        status.textContent = '卷号不合规。';
        return;
      }
      status.textContent = '正投卷…';
      try {
        const res = await fetch('/api/upload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          status.textContent = `失败 ${res.status}：${data.error || res.statusText}`;
          return;
        }
        status.textContent = `入藏成功 · ${data.id} · md5 ${data.md5 || '—'}`;
        toast('入藏成功');
      } catch (err) {
        status.textContent = `网络失败：${err.message || err}`;
      }
    });

    $('#btn-import-paste')?.addEventListener('click', () => {
      try {
        const raw = $('#import-text').value.trim();
        if (!raw) { toast('粘贴区为空'); return; }
        importPayload(JSON.parse(raw));
      } catch (e) {
        toast(`导入失败：${e.message || e}`);
      }
    });
    $('#import-file')?.addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        importPayload(JSON.parse(text));
      } catch (err) {
        toast(`读文件失败：${err.message || err}`);
      }
      e.target.value = '';
    });
  }

  async function boot() {
    try {
      const res = await fetch('/assets/designer-schema.json', { cache: 'no-store' });
      if (!res.ok) throw new Error(`schema ${res.status}`);
      SCHEMA = await res.json();
    } catch (e) {
      document.querySelector('.designer-main').innerHTML =
        `<div class="error-state"><p class="empty-title">图谱未至</p><p class="empty-hint">未能加载 designer-schema.json（${e.message}）</p></div>`;
      return;
    }
    // seed a minimal example so first visit can export
    if (!state.content.weaponLooks.length) {
      state.content.weaponLooks.push({
        id: 'lookDemoPlain',
        label: '试笔直刃',
        baseShape: 'sword',
        parts: [
          { kind: 'palette', blade: '#e9eef7', trail: '#ff2040', edge: '#ff4a66', grip: '#3a2a18' },
          { kind: 'grip', length: 10, width: 3.2 },
          { kind: 'guard', style: 'cross', width: 11 },
          { kind: 'blade', profile: 'straight', lengthFrac: 1 },
          { kind: 'tip', style: 'point' },
          { kind: 'inkEdge' },
        ],
      });
    }
    // W4：首访即有可导出的兵刃（挂 lookId）+ 一招外功（挂既有 attackKey）
    if (!state.content.weapons.length) {
      state.content.weapons.push({
        id: 'demo_canfeng',
        name: '试笔残锋',
        lore: '设计台默认示范刃，对照内容包 bingren / qiangying 字段。',
        tip: '刀剑 · 外观 lookDemoPlain',
        unlock: { type: 'blueprint', hint: '设计台试笔' },
        damage: 0.96, speed: 1.04, reach: 1.02, poise: 0.95, rage: 1.0, airHover: 1.0,
        weight: 'medium', category: 'blade',
        affinities: ['juggle'], affinityBonus: 0.12,
        blade: '#e9eef7', trail: '#ff2040', edge: '#ff4a66', length: 56, shape: 'sword',
        quality: 'fan', tier: 1,
        lookId: 'lookDemoPlain',
        feel: { boxTune: { tipXPush: 6, tipWFloorMul: 0.95 } },
        craft: { materials: { iron: 2, silk: 1 }, fee: 12 },
      });
    }
    if (!state.content.skills.length) {
      state.content.skills.push({
        id: 'demo_canmang',
        name: '试笔残锋诀',
        fogName: '武学·锋??',
        kind: 'active',
        track: 'combat',
        lore: '设计台默认外功：挂长夜既有攻击盒 daomang，不自造盒。',
        tip: '刀剑：试斩 · 耗内力',
        profHint: '持刀剑施放',
        meditateCost: {},
        fee: 0,
        quality: 'fan',
        weaponGate: 'blade',
        neiliCost: 28,
        castKind: 'attack',
        attackKey: 'daomang',
        commandSeq: ['D', 'F'],
        commandLabel: '↓→攻',
        hudHint: '试笔↓→J',
        touchPriority: 50,
      });
    }
    if (!state.content.animRecipes.length) {
      state.content.animRecipes.push({
        id: 'animDemoSlash',
        label: '试笔墨斩',
        steps: [
          { kind: 'playPose', poseId: 'slash1', frames: 5 },
          { kind: 'swingArc', radius: 72, sweep: 1.35, color: '#e8d0a0', frames: 8 },
          { kind: 'sfx', id: 'slash' },
        ],
      });
    }

    renderMeta();
    for (const s of Object.keys(LIST_KEYS)) {
      renderTray(s);
      renderRecipeEditor(s);
    }
    renderGameplay();
    renderStages();
    wire();
    refreshExportPreview();
    showWorkbench(false);
    // warm-load act skeletons (non-blocking)
    fetch('/assets/stage-skeletons.json', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => { if (j) STAGE_SKELS = j; })
      .catch(() => {});
  }

  boot();
})();
